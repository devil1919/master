##COPYRIGHT ADITYA KUMBHAR

n= int(input("Enter size of board: "))
mat = [[0]*n for i in range(n)]


def safe_row(x):
    if(1 in mat[x]):
        return 0
    return 1

def safe_col(y):
    for i in range(n):
        if mat[i][y]==1:
            return 0
    return 1

def safe_diag_left(x,y):
    i,j=x,y
    while(i>=0 and j>=0):
        if(mat[i][j]==1):
            return 0
        i-=1
        j-=1
    i,j=x,y
    while(i<n and j<n):
        if(mat[i][j]==1):
            return 0
        i+=1
        j+=1
    return 1


def safe_diag_right(x,y):
        i,j=x,y
        while(i>=0 and j<n):
            if(mat[i][j]==1):
                return 0
            i-=1
            j+=1
        i,j=x,y
        while(i<n and j>=0):
            if(mat[i][j]==1):
                return 0
            i+=1
            j-=1
        return 1

queens=[]
for i in range(n):
    queens.append([i,0])

placed = 0
x = queens[placed][0]
y = queens[placed][1]

while(placed<n):
    if(y<n and safe_row(x)==1 and safe_col(y)==1 and safe_diag_left(x,y)==1 and safe_diag_right(x,y)==1):
        queens[placed][1]=y
        mat[queens[placed][0]][queens[placed][1]] = 1
        placed+=1
        if(placed==n):
            break
        x = queens[placed][0]
        y = queens[placed][1]
    else:
        if(y<n-1):
            y+=1
        else:
            placed-=1
            while(queens[placed][1]==n-1):
                mat[queens[placed][0]][queens[placed][1]] = 0
                queens[placed][1]=0
                placed-=1
            mat[queens[placed][0]][queens[placed][1]] = 0
            y = queens[placed][1]+1
            x = placed

print(queens)
for x in mat:
    print(x)
