
class Node:

	def __init__(self, f=0, g=999999, h=0, name=0):
		self.f = f
		self.g = g
		self.h = h
		self.name = name

	def setNeighbours(self, neighbours={}):
		self.neighbours = neighbours


n = int(input("Enter number of nodes: "))
print("Enter adjacency matrix: ")
graph = []
for i in range(n):
	graph.append([int(k) for k in input().split()])

# input heuristics for each node
heuristics = [int(k) for k in input("Enter heuristics for nodes: ").split()]
nodes=[]
for i,x in enumerate(heuristics):
	nodes.append(Node(h=x,name=i))


for i in range(n):
	neighbours=[]
	for j in range(n):
		if(graph[i][j]!=-1):
			neighbours.append(nodes[j])
	nodes[i].setNeighbours(neighbours)

startNode = nodes[0]
goalNode = nodes[n-1]


def astar(start,goal):

	closedSet = set([])
	openSet = set([start])

	cameFrom = {}

	start.g = 0
	start.f = start.h


	while len(openSet)!=0:

		current = findNodeWithLowestFScore(openSet)

		if current==goal:
			return contruct_path(cameFrom, current)

		openSet.remove(current)
		closedSet.add(current)

		#print(current.name, current.f, current.g, current.h)

		for neighbour in current.neighbours:

			#print(neighbour.name, neighbour.f, neighbour.g, neighbour.h)

			if neighbour in closedSet:
				continue

			if neighbour not in openSet:
				openSet.add(neighbour)


			tentative_gScore = current.g + graph[current.name][neighbour.name]
			#print(tentative_gScore)
			if tentative_gScore >= neighbour.g:
				continue

			cameFrom[neighbour] = current
			neighbour.g = tentative_gScore
			neighbour.f = neighbour.g + neighbour.h



	return -1

def findNodeWithLowestFScore(openSet):
	fScore = 999999
	node = None
	for eachNode in openSet:
		if eachNode.f < fScore:
			fScore = eachNode.f
			node = eachNode

	return node


def contruct_path(cameFrom, current):

	totalPath = []
	while current in cameFrom.keys():
		current = cameFrom[current]
		totalPath.append(current)

	return totalPath



if __name__=="__main__":


	path = astar(startNode, goalNode)

	print("Path is : ", end="" )
	for node in path[::-1]:
		print(str(node.name) + "-->", end="")
	print(goalNode.name)

	print("\nCost = " + str(goalNode.g))
