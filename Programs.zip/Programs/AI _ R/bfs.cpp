#include <iostream>
#include <queue>
using namespace std;

void bfs(int adj_mat[][50],int n,int s){
  queue<int> Q;
  queue<int> bfs_tree;

  Q.push(s);
  int vis[n];
  for(int i=0;i<n;i++)
    vis[i]=0;

  while(!Q.empty()){
      int k = Q.front();
      Q.pop();
      vis[k]=1;
      bfs_tree.push(k);
      for(int i=0;i<n;i++)
        if(adj_mat[k][i]>0 && !vis[i])
          Q.push(i);
  }
  cout<<"BFS traversal: ";
  while (!bfs_tree.empty())
   {
     cout << ' ' << bfs_tree.front();
     bfs_tree.pop();
   }
   cout<<endl;
}



int main(){
  int adj_mat[50][50];
  int n,s;
  cout << "Enter number of nodes: ";
  cin>>n;
  cout << "Enter adjacency matrix" << '\n';

  for(int i =0; i< n; i++){
    for(int j=0; j<n; j++)
      cin>>adj_mat[i][j];
  }

  cout<<"Enter source node between [0-"<<n-1<<"]: ";
  cin>>s;
  bfs(adj_mat,n,s);
}
