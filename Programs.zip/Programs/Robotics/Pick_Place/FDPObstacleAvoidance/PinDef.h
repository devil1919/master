#define leftPin2 A4
#define leftPin1 A5
#define rightPin2 A0
#define rightPin1 A1

#define triggerPin 3
#define echoPin 2
#define maxDistance 200
