#include <iostream>
#include <omp.h>
using namespace std;

int main()
{
    
    int N;
    cout << "Enter size of vectors";
    cin >> N;
    int a[N],b[N],c[N];
    cout << endl << "Enter elements of vector 1:" << endl;
        for(int j = 0; j < N; ++j)
        {
            cout << "Enter element a" << j + 1 << " : ";
            cin >> a[j];
        }
    cout << endl << "Enter elements of vector 2:" << endl;
        for( int j = 0; j < N; ++j)
        {
            cout << "Enter element b"<< j + 1 << " : ";
            cin >> b[j];
        }
    
        for(int j = 0; j < N; ++j)
        {
            c[j]=0;
        }
    #pragma omp parallel for
    for(int j = 0; j < N; ++j)
            {
                c[j] = a[j] + b[j];
            }


    cout << endl << "Output Vector: " << endl;
    
    for(int j = 0; j < N; ++j)
    {
        cout<< c[j]<<" ";
       
    }

    return 0;
}
