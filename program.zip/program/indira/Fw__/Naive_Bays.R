mydata <- read.csv(file= "D:\\Aparna\\Data Analytics\\LP1\\diabetes.csv",header= TRUE,sep=",")
View(mydata)
dim(mydata)
#to split dataset into train and test sets install  caTools package
install.packages("caTools")
library(caTools)
install.packages("mlbench")
library(mlbench)
#divide dataset inti train and test dataset

train<- as.data.frame(mydata[1:700,])
str(train)
test<-as.data.frame(mydata[701:768,])
str(test)
#The e1071 package in R has a built-in nai veBayes function that can compute the conditional
#probabilities of a categorical class variable given independent categorical predictor variables using the
#Bayes rule. The function takes the form of nai veBayes (formula I data I ... )
install.packages("e1071")
library(e1071)
View(train)

my_model <- naiveBayes(as.factor(train$Outcome)~ .,train,laplace = .1)
my_model
results<-predict(my_model,test)

# prints the values stored in result variable
results

# generating confusing matrix
library(caret)
install.packages("caret")

# to evaluate the performance of classifier Confusion matrix is bulid

s<-confusionMatrix(results,test$Outcome)
s
# other way of printing confusion matrix

table(results,test$Outcome,dnn = c("Actual","predicted"))

# Predicted result of build model is saved in variable results, values of which are binf to train dataset to crosscheck the values predicted by out model
output <- cbind(test,results)

# View table Output which consist of 10 valiables (columns) last column are values predicted by build model
View(output)
# observe the structure of  mydata and output datasets
str(mydata)
str(output)
View(output)
