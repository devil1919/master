global board
board=[['A','B','C'],['E','F','_'],['G','H','D']]
global goal
goal=[['A','B','C'],['E','H','F'],['_','G','D']]



def copy_board(Board):
	new=[[],[],[]]
	for i in range(3):
		for j in range(3):
			new[i].append(Board[i][j])
	return new
def moves_poss(temp_board):
	ii=0
	jj=0
	temp_moves=[0,0,0,0]
	for i in range(3):
		if '_' in temp_board[i]:
			ii=i
			jj=temp_board[i].index('_')
	if(ii-1>=0):
		temp_moves[2]=1
	if(ii+1<=2):
		temp_moves[3]=1
	if(jj-1>=0):
		temp_moves[0]=1
	if(jj+1<=2):
		temp_moves[1]=1
	return temp_moves
def makeMove(temp_board,move):
	ii=0
	jj=0
	if(move=="left"):
		for i in range(3):
			if '_' in temp_board[i]:
				ii=i
				jj=temp_board[i].index('_')
		ele=temp_board[ii][jj-1]
		temp_board[ii][jj-1]='_'
		temp_board[ii][jj]=ele
		return temp_board
	if(move=="right"):
		for i in range(3):
			if '_' in temp_board[i]:
				ii=i
				jj=temp_board[i].index('_')
		ele=temp_board[ii][jj+1]
		temp_board[ii][jj+1]='_'
		temp_board[ii][jj]=ele
		return temp_board
	if(move=="up"):
		for i in range(3):
			if '_' in temp_board[i]:
				ii=i
				jj=temp_board[i].index('_')
		ele=temp_board[ii-1][jj]
		temp_board[ii-1][jj]='_'
		temp_board[ii][jj]=ele
		return temp_board
	if(move=="down"):
		for i in range(3):
			if '_' in temp_board[i]:
				ii=i
				jj=temp_board[i].index('_')
		ele=temp_board[ii+1][jj]
		temp_board[ii+1][jj]='_'
		temp_board[ii][jj]=ele
		return temp_board
	
def heuristic(temp_board):
	count=0
	for i in range(3):
		for j in range(3):
			if goal[i][j]!=temp_board[i][j]:
				count+=1
	return count

def printBoard(temp_board):
	for i in temp_board:
		for j in i:
			print " "+j+" ",
		print
	print	

curr_board=board
print "initial state"
printBoard(curr_board)
print "goal state"
printBoard(goal)
print 
while(curr_board!=goal):
	minheu=999
	#printBoard(curr_board)
	curr_moves=moves_poss(curr_board)
	#curr_heuristic=heuristic(curr_board)
	next_board=[]
	next_board=copy_board(curr_board)
	if(curr_moves[0]==1):
		temp_board=copy_board(curr_board)
		temp_board=makeMove(temp_board,"left")
		temp_heuristics=heuristic(temp_board)
		if(temp_heuristics<=minheu):
			minheu=temp_heuristics
			next_board=copy_board(temp_board)
			
			
			
	if(curr_moves[1]==1):
		
		temp_board=copy_board(curr_board)
		
		temp_board=makeMove(temp_board,"right")
		temp_heuristics=heuristic(temp_board)
		if(temp_heuristics<=minheu):
			minheu=temp_heuristics
			next_board=copy_board(temp_board)
			
			
			
	if(curr_moves[2]==1):
		
		temp_board=copy_board(curr_board)
		
		temp_board=makeMove(temp_board,"up")
		temp_heuristics=heuristic(temp_board)
		if(temp_heuristics<=minheu):
			minheu=temp_heuristics
			next_board=copy_board(temp_board)
			
			
			
	if(curr_moves[3]==1):
		
		temp_board=copy_board(curr_board)
		
		temp_board=makeMove(temp_board,"down")
		temp_heuristics=heuristic(temp_board)
		if(temp_heuristics<=minheu):
			minheu=temp_heuristics
			next_board=copy_board(temp_board)
			
	curr_board=next_board
	
	printBoard(curr_board)
#######################################output###############################
'''
initial state
 A   B   C 
 E   F   _ 
 G   H   D 

goal state
 A   B   C 
 E   H   F 
 _   G   D 


 A   B   C 
 E   _   F 
 G   H   D 

 A   B   C 
 E   H   F 
 G   _   D 

 A   B   C 
 E   H   F 
 _   G   D 

'''
			
	
