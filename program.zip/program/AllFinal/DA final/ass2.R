library(caret)
library(caTools)
library(e1071)

mydata<-read.csv(file="C:\\Users\\Mr Kadarsh\\Desktop\\practical\\LP1\\da\\diabetes.csv")
mydata
View(mydata)
dim(mydata)

set.seed(123)
samp<-sample(nrow(mydata),0.6*nrow(mydata))
train<-mydata[samp, ]
test<-mydata[-samp, ]
dim(train)
dim(test)

my_model<- naiveBayes(as.factor(train$Outcome)~.,train)
my_model

pred1<-predict(my_model,test[,-9])
pred1

table(pred1,test$Outcome,dnn=c("predicated","actual"))

output<-cbind(pred1,test)
View(output)