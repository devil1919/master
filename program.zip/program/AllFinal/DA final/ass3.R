library(caret)
library(caTools)
library(e1071)
library(dplyr)
library(rpart)
library(rpart.plot)

mydata<-read.csv(file = "C:\\Users\\Mr Kadarsh\\Desktop\\practical\\LP1\\da\\bike.csv")
mydata
View(mydata)
dim(mydata)

samp=sample(nrow(mydata),0.7*nrow(mydata))
train<-mydata[samp, ]
test<-mydata[-samp, ]
dim(train)
dim(test)

samp1<-createDataPartition(y=mydata$Member.type,p=0.7,list=FALSE)
train1<-mydata[samp1, ]
test1<-mydata[-samp1, ]
dim(train1)
dim(test1)

library(rattle)
library(RColorBrewer)
d=rpart(Duration~.,data=train)
fancyRpartPlot(d)

model <- rpart(End.station.number~., data=train)
prp(model, type=2, extra=1)


#fit <-rpart(End.station~.,method = 'class',data = train, control=rpart.control(minsplit=10),parms=list(split= 'information'))

summary(model)

rpart.plot(model,type=2,extra=1)

new_data=data.frame(test1)

pred2<-predict(model,new_data=new_data,method=prob)
pred2
pred1<-predict(model,new_data=new_data,method=class)
pred1

output <-cbind(pred2,pred1)
View(output)


