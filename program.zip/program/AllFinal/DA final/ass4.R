library(ggplot2)
library(gridExtra)

library(caret)
library(caTools)

library(dplyr)
library(plyr)

library(corrplot)

bigmart <-read.csv(file= "C:\\Users\\Mr Kadarsh\\Desktop\\practical\\LP1\\da\\bigmart_train.csv", header=TRUE,sep =",")
View(bigmart)
table(is.na(bigmart))  #for any missing value

colSums(is.na(bigmart)) #where exactly it is

#view data
ggplot(bigmart, aes(Item_Type, Item_Weight)) +geom_boxplot() +  theme(axis.text.x = element_text(angle = 70, vjust = 0.5, color = "black")) +   xlab("Item Type") +   ylab("Item Weight") +   ggtitle("Item Weight vs Item Type")
ggplot(bigmart, aes(Outlet_Identifier, Item_Weight)) +geom_boxplot() +  theme(axis.text.x = element_text(angle = 70, vjust = 0.5, color = "black")) +   xlab("Outlet_Identifier") +  ylab("Item Weight") +   ggtitle("Item Weight vs Outlet identifier")

#data partition
intrain <- createDataPartition(y = bigmart$Item_Outlet_Sales, p= 0.7, list = FALSE,times = 1)

train <- bigmart[intrain,]
test <- bigmart[-intrain,]
dim(train)
str(train)
summary(train)

#data cleaning
test$Item_Outlet_Sales <-  0
combi <- rbind(train, test)

#correlation
corMatrix <- cor(combi[1:nrow(train),][sapply(combi[1:nrow(train),], is.numeric)])

corMatrix
corrplot::corrplot(corMatrix, method="number", type="upper")

ggplot(combi[1:nrow(train),], aes(x = Item_Type, y = Item_Outlet_Sales, fill = Outlet_Type)) +  geom_boxplot() +  theme(axis.text.x = element_text(angle = 70, vjust = 0.5, color = "black")) +   xlab("Item type") +  ylab("Sales") +   ggtitle("Sales vs Item type")

max(combi$Item_MRP)
min(combi$Item_MRP)

#linear regression
model1 <- lm(bigmart$Item_Outlet_Sales ~ bigmart$Item_Visibility, data=train)
summary(model1) # show results

plot(train$Item_Outlet_Sales,train$Item_Visibility)

plot(model1,col="red")

new_data=data.frame(bigmart$Item_Outlet_Sales)
new_data
dim(new_data)

pred_temp1=predict(model1,newdata=new_data)
pred_temp1

output1 <-cbind(bigmart,pred_temp1)
View(output1)

model2 <- lm(bigmart$Item_Outlet_Sales ~ bigmart$Item_MRP+bigmart$Item_Visibility+bigmart$Item_Weight, data=train)

summary(model2) # show results

plot(train$Item_Outlet_Sales,train$Item_MRP,col= "blue")

plot(model2,col="red")
new_data=data.frame(bigmart$Item_Outlet_Sales)
new_data
dim(new_data)

pred_temp2=predict(model2,newdata=new_data)
pred_temp2

#To save prediction on visibility
output <-cbind(bigmart,pred_temp2)
View(output)




