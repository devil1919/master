# split data into train data and test data percentile split-install catools from tools->intall packages
# catool has function 
library(caTools)

# ML package used for naive bayes but can be used for SVM, fuzzy clustering and so on
# if package not available goto Tool -> Insatll Package e1071
library(e1071)

#read dataset in mydata
mydata <-read.csv(file= "H:\\practical\\da\\diabetes.csv", header=TRUE,sep =",")

# check dataset
View(mydata)

# using sample.split from mydata with ratio 70/30
temp_field <- sample.split(mydata,SplitRatio = 0.7)
                           
#70% will be in training 
train <- subset(mydata, temp_field= TRUE)

# 30% will be  in testing
test <- subset(mydata, temp_field= FALSE)

#display few samples
head(train)
head(test)

#....................part2..........................
my_model <-naiveBayes(as.factor(train$Outcome)~.,train)

# to see summary of the probabilities calculated
my_model

#..........................part3......................
# predicting, try putting type= class or type raw after the all value except 9 th col

pred1<- predict(my_model,test[,-9])
pred1

# generate the confusion matrix
table(pred1,test$Outcome,dnn = c("predicted","actual"))

# to save prediction
output <-cbind(test,pred1)
View(output)
