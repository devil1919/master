data("iris")
head(iris) #gives 1st few records of datasets.
summary(iris)
names(iris) #list of iris attributes with name
dim(iris) #give dimension
View(iris)
str(iris$Sepal.Length) #Show Types of data
str(iris) #structure of data sets
#The output shows that there are 150 observations and 5 variables.
#Four of the variables viz., Sepal.Length, Sepal.Width,Petal.Length, and Petal.Width, 
#are numeric, while the fifth, Species, is a factor. 
#The factor has three levels, but only two are displayed.
#Let us see what the third is with the help of the levels() function.
levels(iris$Species)

#So, there are three levels and these levels seem to be three species of Iris. 
#Let us see how the data are distributed among the three species.

table(iris$Species)

mean(iris$Sepal.Length) # find the mean

#we want to calculate the mean of the Sepal Length but broken by the Species,
#so we will use the tapply() function
tapply(iris$Sepal.Length,iris$Species,mean)

#to draw the histogram
hist(iris$Sepal.Length)

#break in bar
hist(iris$Sepal.Length,breaks =20)
#color the histogram
hist(iris$Sepal.Length,breaks =20,col = "blue")

median(iris$Sepal.Length) #to find median
var(iris$Sepal.Length) #to find variation
sd(iris$Sepal.Length) #to find standard deviation

barplot(table(iris$Sepal.Length), col="blue", xlab="Sepal.Length", ylab="Count", main="Bar plot of Sepal Length")
