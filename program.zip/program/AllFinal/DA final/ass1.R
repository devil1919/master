library(datasets)
data("iris")
View(iris)

str(iris)
summary(iris)

library(ggplot2)
library(readr) 
library(gridExtra)
library(grid)
library(plyr)

iris[sample(nrow(iris),10),]  #random sampling of data

HisSl <- ggplot(data=iris, aes(x=Sepal.Length))+geom_histogram(binwidth=0.2, color="black", aes(fill=Species)) + xlab("Sepal Length (cm)") +  ylab("Frequency") + theme(legend.position="none")+ggtitle("Histogram of Sepal Length")+geom_vline(data=iris, aes(xintercept = mean(Sepal.Length)),linetype="dashed",color="grey")

HistSw <- ggplot(data=iris, aes(x=Sepal.Width)) +geom_histogram(binwidth=0.2, color="black", aes(fill=Species)) + xlab("Sepal Width (cm)") +   ylab("Frequency") + theme(legend.position="none")+ggtitle("Histogram of Sepal Width")+geom_vline(data=iris, aes(xintercept = mean(Sepal.Width)),linetype="dashed",color="grey")


HistPl <- ggplot(data=iris, aes(x=Petal.Length))+geom_histogram(binwidth=0.2, color="black", aes(fill=Species)) + xlab("Petal Length (cm)") +  ylab("Frequency") + theme(legend.position="none")+ggtitle("Histogram of Petal Length")+geom_vline(data=iris, aes(xintercept = mean(Petal.Length)),linetype="dashed",color="grey")

HistPw <- ggplot(data=iris, aes(x=Petal.Width))+geom_histogram(binwidth=0.2, color="black", aes(fill=Species)) + xlab("Petal Width (cm)") +  ylab("Frequency") + theme(legend.position="right" )+ggtitle("Histogram of Petal Width")+geom_vline(data=iris, aes(xintercept = mean(Petal.Width)),linetype="dashed",color="grey")

grid.arrange(HisSl + ggtitle(""),HistSw + ggtitle(""),HistPl + ggtitle(""),HistPw  + ggtitle(""),nrow = 2,top = textGrob("Iris Frequency Histogram", gp=gpar(fontsize=15)))

BpSl <- ggplot(iris, aes(Species, Sepal.Length, fill=Species)) + geom_boxplot()+scale_y_continuous("Sepal Length (cm)", breaks= seq(0,30, by=.5))+theme(legend.position="none")

BpSw <- ggplot(iris, aes(Species, Sepal.Width, fill=Species)) + geom_boxplot()+scale_y_continuous("Sepal Width (cm)", breaks= seq(0,30, by=.5))+theme(legend.position="none")

BpP1 <- ggplot(iris, aes(Species, Petal.Length, fill=Species)) + geom_boxplot()+scale_y_continuous("Petal Length (cm)", breaks= seq(0,30, by=.5))+theme(legend.position="none")

BpPw <- ggplot(iris, aes(Species, Petal.Width, fill=Species)) + geom_boxplot()+scale_y_continuous("Petal Width (cm)", breaks= seq(0,30, by=.5))+theme(legend.position="none")

grid.arrange(BpSl  + ggtitle(""),BpSw  + ggtitle(""), BpP1 + ggtitle(""), BpPw + ggtitle(""), nrow = 2,top = textGrob("Sepal and Petal Box Plot", gp=gpar(fontsize=15)))


#we can plot histogram withou ggplot
hist(iris$Petal.Width)
hist(iris$Petal.Width, breaks=20, col="grey")

#same for box plot
boxplot(iris$Sepal.Length)
#we can use min,max,sd,var,mean function as well
